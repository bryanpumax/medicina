CREATE DATABASE IF NOT EXISTS `bdd_ruta`;

USE `bdd_ruta`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `auditoria`;

CREATE TABLE `auditoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_old` longtext COLLATE utf8mb4_spanish_ci NOT NULL,
  `nom_new` longtext COLLATE utf8mb4_spanish_ci NOT NULL,
  `dir_old` longtext COLLATE utf8mb4_spanish_ci NOT NULL,
  `dir_new` longtext COLLATE utf8mb4_spanish_ci NOT NULL,
  `tabla` longtext COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `auditoria` VALUES (0,"FELIX","FELIX DEL  DIA",32,32,"tbl_medico");


DROP TABLE IF EXISTS `excel`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `excel` AS select `view_visitas`.`idx_visita` AS `idx_visita`,`view_visitas`.`nom_visita` AS `nom_visita`,`view_visitas`.`dir_visita` AS `dir_visita`,`view_visitas`.`esp_especialidades` AS `esp_especialidades`,`view_visitas`.`operador` AS `operador`,`view_muestra`.`nomp_producto` AS `nomp_producto`,`tbl_det_muestra`.`cant_det_muestra` AS `cant_det_muestra`,`view_muestra`.`idx_muestra` AS `idx_muestra`,`view_visitas`.`fech_visita` AS `fech_visita`,`view_muestra`.`cont_muestra` AS `cont_muestra`,`view_visitas`.`localizacion` AS `localizacion` from ((`view_visitas` join `tbl_det_muestra` on((`tbl_det_muestra`.`idx_vista` = `view_visitas`.`idx_visita`))) join `view_muestra` on((`view_muestra`.`idx_muestra` = `tbl_det_muestra`.`idx_muestra`))) where ((`tbl_det_muestra`.`idx_vista` = `view_visitas`.`idx_visita`) and (`tbl_det_muestra`.`idx_muestra` = `view_muestra`.`idx_muestra`));

INSERT INTO `excel` VALUES (54,"BRYAN CORNEJO","TSACHILA Y  GUAYAQUIL","GINECOLOGIA","ADMIN ADMIN","ATENNOR",42,3,"2019-06-02",16,"SANTO DOMINGO / JEJEJE");


DROP TABLE IF EXISTS `tbl_citas`;

CREATE TABLE `tbl_citas` (
  `id_citas` int(11) NOT NULL AUTO_INCREMENT COMMENT 'identificador DE  LA  TABLA',
  `fecha_citas` date DEFAULT NULL COMMENT 'FECHA',
  `hora_citas` time DEFAULT NULL COMMENT 'HORA',
  `idx_clientes` int(11) DEFAULT NULL COMMENT 'RELACION TABLA DEL CLIENTE',
  `idx_operador` int(11) DEFAULT NULL COMMENT 'RELACION TABLA DEL OPERADOR',
  `estado_citas` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL COMMENT 'ESTADO DE LA ACCION',
  `obseravacion_citas` longtext COLLATE utf8_spanish_ci COMMENT 'OPINION DE CLIENTE',
  PRIMARY KEY (`id_citas`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `tbl_citas` VALUES (1,"2019-05-26","22:11:00",1,4,"activo",""),
(2,"2019-05-26","23:33:00",5,4,"activo",""),
(3,"2019-05-27","15:06:00",6,5,"activo","");


DROP TABLE IF EXISTS `tbl_ciudades`;

CREATE TABLE `tbl_ciudades` (
  `idx_ciudades` int(11) NOT NULL AUTO_INCREMENT,
  `nom_ciudades` varchar(120) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `cont_ciudades` int(11) DEFAULT NULL,
  PRIMARY KEY (`idx_ciudades`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `tbl_ciudades` VALUES (1,"LOS RÃ­OS",0),
(2,"BAÃ±OS",0),
(3,"SANTO DOMINGO",3),
(4,"ESMERALDAS",0),
(5,"MANABI",0),
(6,"SANTA ELENA",0),
(7,"GUAYAS",0),
(9,"EL ORO",0),
(10,"AZUAY",0),
(11,"BOLIVAR",0),
(12,"CAÃ±AR",0),
(13,"CARCHI",0),
(14,"COTOPAXI",0),
(15,"CHIMBORAZO",0),
(16,"IMBABURA",0),
(17,"LOJA",0),
(18,"PINCHINCHA",0),
(19,"TUNGURAHUA",0),
(20,"MORONA SANTIAGO",0),
(21,"NAPO",0),
(22,"ORELLANA",0),
(23,"PASTAZA",0),
(24,"SUCUMBIOS",0),
(25,"ZAMORA",0),
(26,"ALFA DE MEDITERRANEO",0),
(32,"AAAAAAA",0),
(33,"AAAAAAAA",0),
(34,"AAAAAAAAA",0),
(35,"AAAAAAAAAA",0);


DROP TABLE IF EXISTS `tbl_clientes`;

CREATE TABLE `tbl_clientes` (
  `idx_clientes` int(11) NOT NULL AUTO_INCREMENT,
  `cru_clientes` varchar(10) CHARACTER SET latin1 NOT NULL,
  `nom_clientes` varchar(120) CHARACTER SET latin1 NOT NULL,
  `ape_clientes` varchar(120) CHARACTER SET latin1 NOT NULL,
  `idx_rutas` int(11) NOT NULL,
  `dir_clientes` varchar(120) CHARACTER SET latin1 NOT NULL,
  `telf_clientes` varchar(10) CHARACTER SET latin1 NOT NULL,
  `cel_clientes` varchar(10) CHARACTER SET latin1 NOT NULL,
  `email_clientes` varchar(120) CHARACTER SET latin1 NOT NULL,
  `emp_clientes` varchar(120) CHARACTER SET latin1 NOT NULL,
  `idx_operador` int(11) NOT NULL,
  PRIMARY KEY (`idx_clientes`),
  KEY `ruta` (`idx_rutas`),
  CONSTRAINT `ruta` FOREIGN KEY (`idx_rutas`) REFERENCES `tbl_rutas` (`idx_rutas`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `tbl_clientes` VALUES (5,1717565665,"BRYAN","CORNEJO",21,"TSACHILA Y  GUAYAQUIL",0959113935,"","riqbran@hotmail.com","PC-SANTO DOMINGO",4),
(6,1720836400,"LOLI","K",22,"EW",32,"","d@m.cpm","D",5);


DROP TABLE IF EXISTS `tbl_det_muestra`;

CREATE TABLE `tbl_det_muestra` (
  `idx_det_muestra` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  `idx_vista` int(11) NOT NULL,
  `idx_muestra` int(11) NOT NULL,
  `cant_det_muestra` int(11) NOT NULL,
  `fecha_det_muestra` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

INSERT INTO `tbl_det_muestra` VALUES ("PAR00145",41,46,3,"2019-05-26"),
("PAR00149",42,44,32,"2019-05-26"),
("PAR00150",43,44,4,"2019-05-26"),
("PAR00150",44,43,3,"2019-05-26"),
("PAR00151",45,45,32,"2019-05-26"),
("PAR00152",46,43,32,"2019-05-26"),
("PAR00153",47,44,32,"2019-05-26"),
("PAR00155",48,43,32,"2019-05-27"),
("PAR00156",49,44,14,"2019-05-27"),
("PAR00157",50,46,41,"2019-05-27"),
("PAR00158",51,43,324,"2019-05-27"),
("PAR00159",52,3,32,"2019-06-01"),
("PAR00162",53,2,3,"2019-05-28"),
("PAR00173",54,3,42,"2019-06-02");


DROP TABLE IF EXISTS `tbl_det_pedido`;

CREATE TABLE `tbl_det_pedido` (
  `idx_det_pedido` int(11) NOT NULL AUTO_INCREMENT,
  `idx_perdido` varchar(11) CHARACTER SET latin1 NOT NULL,
  `idx_producto` int(11) NOT NULL,
  `cant_det_pedido` int(11) NOT NULL,
  `pre_det_pedido` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pro_det_pedido` int(11) NOT NULL DEFAULT '0',
  `iva_det_pedido` decimal(10,2) NOT NULL DEFAULT '0.00',
  `subt_det_pedido` decimal(7,2) NOT NULL,
  PRIMARY KEY (`idx_det_pedido`),
  KEY `inventario` (`idx_producto`),
  KEY `pedido` (`idx_perdido`),
  CONSTRAINT `inventario` FOREIGN KEY (`idx_producto`) REFERENCES `tbl_inventario` (`idx_producto`),
  CONSTRAINT `pedido` FOREIGN KEY (`idx_perdido`) REFERENCES `tbl_perdido` (`idx_perdido`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `tbl_det_pedido` VALUES (1,"COT00039",30,32,"22.56",0,"0.00","721.92"),
(2,"COT00040",1,5,"16.38",1,"0.00","98.28");


DROP TABLE IF EXISTS `tbl_diario`;

CREATE TABLE `tbl_diario` (
  `Nro_informe` varchar(15) COLLATE utf8mb4_spanish_ci NOT NULL,
  `fec_informe` date NOT NULL,
  `rut_informe` varchar(235) COLLATE utf8mb4_spanish_ci NOT NULL,
  `est_informe` varchar(15) COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT 'Generado',
  `idx_operador` int(11) NOT NULL,
  PRIMARY KEY (`Nro_informe`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `tbl_diario` VALUES ("JUAINF20","2019-05-27","JUAInforme_2019-05-27.xlsx","Actualizado",5),
("JUAINFMEN22","2019-05-27","JUAInforme_mensual_2019-05-27.xlsx","Generado Mensua",5),
("USUINF19","2019-05-01","USUInforme_2019-05-27.xlsx","Actualizado",4),
("USUINF25","2019-05-28","USUInforme_2019-05-28.xlsx","Generado",4),
("USUINF26","2019-05-08","USUInforme_2019-05-08.xlsx","Generado",4),
("USUINFMEN21","2019-05-27","USUInforme_2019-05-27.xlsx","Actualizado",4),
("USUINFMEN23","2019-05-27","USUInforme_mensual_2019-05-27.xlsx","Generado Mensua",4),
("USUINFMEN24","2019-06-01","USUInforme_mensual_2019-06-01.xlsx","Generado Mensua",4);


DROP TABLE IF EXISTS `tbl_especialidades`;

CREATE TABLE `tbl_especialidades` (
  `idx_especialidades` int(11) NOT NULL AUTO_INCREMENT,
  `esp_especialidades` varchar(120) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`idx_especialidades`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `tbl_especialidades` VALUES (1,"GINECOLOGIA"),
(2,"MEDICINA INTERNA");


DROP TABLE IF EXISTS `tbl_inventario`;

CREATE TABLE `tbl_inventario` (
  `idx_producto` int(11) NOT NULL AUTO_INCREMENT,
  `nomp_producto` varchar(120) NOT NULL,
  `idx_tipo` int(11) NOT NULL,
  `prec_producto` decimal(7,2) NOT NULL,
  `img_producto` longtext NOT NULL,
  `iva_producto` int(11) NOT NULL,
  `promo_producto` int(11) NOT NULL,
  `caract_inventario` longtext,
  `contar_inventario` int(11) NOT NULL,
  `fecha_parrilla` date NOT NULL,
  PRIMARY KEY (`idx_producto`),
  KEY `tipo` (`idx_tipo`),
  CONSTRAINT `tipo` FOREIGN KEY (`idx_tipo`) REFERENCES `tbl_tipo` (`idx_tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_inventario` VALUES (1,"ATENNOR",1,"16.38","foto.jpg",0,1,"Caja x 14 Tabletas",1,"2019-05-08"),
(2,"ANTIFUX",2,"27.58","foto.jpg",0,0,"Caja x 14 C&aacute;psulas",1,"2019-05-08"),
(3,"CENTELAR GEL",3,"15.00","foto.jpg",0,0,"Tubo 50 g",1,"0000-00-00"),
(4,"CIFLOBAC TABL 500 MG",6,"7.92","foto.jpg",0,0,"Tabletas Caja x 10",1,"0000-00-00"),
(5,"COLPOSTAT OVULOS",7,"21.00","foto.jpg",0,0,"Ovulos Caja x 7",1,"0000-00-00"),
(6,"COLPOSTAT CREMA",7,"16.50","foto.jpg",0,0,"Crema 30 g Caja x 1",1,"2019-05-08"),
(7,"CRESULIV OVULOS",8,"15.78","foto.jpg",0,0,"Ovulos Caja x 6 ",0,"0000-00-00"),
(8,"DILUPHEN SOBRES",9,"10.08","foto.jpg",0,0,"Sobres Caja x 20 ",0,"0000-00-00"),
(9,"DISFEBRAL SIMPLE",10,"2.70","foto.jpg",0,0,"Suspensi&oacute;n 120 ml ",0,"0000-00-00"),
(10,"DISFEBRAL FAST 400",10,"6.40","foto.jpg",0,0,"Caja x 16 C&aacute;psulas Blandas",0,"0000-00-00"),
(11,"DISFEBRAL FORTE",10,"4.11","foto.jpg",0,0,"Suspensi&oacute;n 120 ml",0,"0000-00-00"),
(12,"DISFEBRAL GOTAS",10,"1.94","foto.jpg",0,0,"Gotas Suspensi&oacute;n 30 ml",0,"0000-00-00"),
(13,"DISFEBRAL 400",10,"4.20","foto.jpg",0,0,"Comprimidos Caja x 20 ",0,"0000-00-00"),
(14,"DISFEBRAL 600",10,"6.00","foto.jpg",0,0,"Tabletas Caja x 20",0,"0000-00-00"),
(15,"ELODERM CREMA",11,"5.75","foto.jpg",0,0,"Tubo 30 g",0,"0000-00-00"),
(16,"EPEROX IBL TABLETAS",12,"26.00","foto.jpg",0,0,"Tabletas Dispersables Caja x 14",0,"0000-00-00"),
(17,"EPEROX IBL SUSPENSION",12,"11.50","foto.jpg",0,0,"Suspension 100 ml",0,"0000-00-00"),
(18,"IVUMOD CAPSULAS",13,"5.83","foto.jpg",0,0,"C&aacute;psulas Caja x 20",0,"0000-00-00"),
(19,"LIDEMIN SOBRES",14,"18.00","foto.jpg",0,0,"Sobres Caja x 30 ",0,"0000-00-00"),
(20,"MIOLOX 75MG ",15,"3.55","foto.jpg",0,0,"Tabletas Caja x 10",1,"0000-00-00"),
(21,"MIOLOX 15",15,"6.08","foto.jpg",0,0,"Tabletas Caja x 10",0,"0000-00-00"),
(22,"MIOLOX GRANULADO",15,"24.92","foto.jpg",0,0,"Sobres Caja x 30",0,"0000-00-00"),
(23,"NITELMIN 200 ",16,"5.30","foto.jpg",0,0,"Tabletas Dispersable Caja x 6",0,"0000-00-00"),
(24,"NITELMIN 500",16,"8.40","foto.jpg",0,0,"tableta caja x6",0,"0000-00-00"),
(25,"NITELMIN SUSPENSION 60",16,"6.57","foto.jpg",0,0,"Suspensi&oacute;n 30 ml",0,"0000-00-00"),
(26,"NITELMIN SUSPENSION 30",16,"3.29","foto.jpg",0,0,"Suspension 30 ml",0,"0000-00-00"),
(27,"SULTAPRIN",17,"13.40","foto.jpg",0,0,"Tabletas Dispersables Caja x 10",0,"0000-00-00"),
(28,"UOSOMOX 250 mg 5ml PPS",12,"3.73","foto.jpg",0,0,"Polvo para suspension 100 ml",0,"0000-00-00"),
(29,"UOSOMOX CAPSULAS ",12,"4.60","foto.jpg",0,0,"Capsulas Caja x 20",0,"0000-00-00"),
(30,"XIMAX TABLETAS 500",21,"22.56","foto.jpg",0,0,"Tabletas dispersables caja x 10 ",1,"0000-00-00"),
(31,"XIMAX SUSPENSION 250",21,"18.00","foto.jpg",0,0,"Suspensi&oacute;n 70 mL 250 mg5 mL",0,"0000-00-00");


DROP TABLE IF EXISTS `tbl_medico`;

CREATE TABLE `tbl_medico` (
  `idxm` int(11) NOT NULL AUTO_INCREMENT,
  `ced_medico` varchar(15) COLLATE utf8mb4_spanish_ci NOT NULL,
  `nom_medi` varchar(120) COLLATE utf8mb4_spanish_ci NOT NULL,
  `dir_medico` longtext COLLATE utf8mb4_spanish_ci NOT NULL,
  `ruta` int(11) NOT NULL,
  `especialidad` int(11) NOT NULL,
  `idx_operador` int(11) NOT NULL,
  PRIMARY KEY (`idxm`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `tbl_medico` VALUES (1,"CLI00097","BRYAN CORNEJO","TSACHILA Y  GUAYAQUIL",23,1,1);


DROP TABLE IF EXISTS `tbl_menu`;

CREATE TABLE `tbl_menu` (
  `idx_menu` int(11) NOT NULL AUTO_INCREMENT,
  `etiq_menu` varchar(120) NOT NULL,
  `ruta_menu` varchar(120) NOT NULL,
  `icono_menu` varchar(120) NOT NULL,
  `rol_menu` int(11) NOT NULL,
  `orden_menu` int(11) DEFAULT NULL,
  `jerarquia` varchar(10) NOT NULL,
  PRIMARY KEY (`idx_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_menu` VALUES (1,"clientes","cliente","fa-border fas fa-users",1,5,"a"),
(2,"ciudades","ciudad","fas fa-city fa-border",3,2,"a"),
(3,"ruta","ruta","fas fa-street-view fa-border",1,3,"a"),
(4,"inventario","invetario","fas fa-warehouse fa-border",1,6,"a"),
(5,"pedido","pedido","far fa-clipboard fa-border",1,7,"m"),
(6,"operador","operador","fas fa-user-tie fa-border",3,4,"a"),
(7,"categoria producto","categoria","fab fa-typo3 fa-border",3,1,"a"),
(8,"reportes/estadistica","reporte","fas fa-chart-pie fa-border",1,8,"r"),
(9,"Citas","citas","fas fa-book-open fa-border",1,6,"m"),
(10,"Visitas","visita","fas fa-street-view fa-border",1,12,"m"),
(11,"Especialidad","especial","fas fa-user-md fa-border",3,12,"a"),
(12,"Reporte Diario/Mensual","diario","fas fa-book fa-fw fa-border",1,2,"r"),
(13,"Medicos","medico","fas fa-user-md fa-border",1,5,"a");


DROP TABLE IF EXISTS `tbl_muestra`;

CREATE TABLE `tbl_muestra` (
  `idx_muestra` int(11) NOT NULL AUTO_INCREMENT,
  `idx_producto` int(11) NOT NULL,
  `fecha_muestra` date NOT NULL,
  `cont_muestra` int(11) NOT NULL,
  `idx_operador` int(11) NOT NULL,
  PRIMARY KEY (`idx_muestra`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

INSERT INTO `tbl_muestra` VALUES (3,1,"2019-06-01",16,4),
(5,2,"2019-05-08",16,4),
(6,1,"2019-05-08",16,4),
(7,6,"2019-05-08",16,4);


DROP TABLE IF EXISTS `tbl_operador`;

CREATE TABLE `tbl_operador` (
  `idx_operador` int(11) NOT NULL AUTO_INCREMENT,
  `ced_operador` varchar(10) CHARACTER SET latin1 NOT NULL COMMENT 'cedula',
  `nom_operador` varchar(120) CHARACTER SET latin1 NOT NULL COMMENT 'nombre',
  `ape_operador` varchar(120) CHARACTER SET latin1 NOT NULL COMMENT 'apellido',
  `tel_operador` varchar(10) CHARACTER SET latin1 NOT NULL COMMENT 'telefono',
  `dir_operador` varchar(120) CHARACTER SET latin1 NOT NULL COMMENT 'direccion',
  `email_operador` varchar(120) CHARACTER SET latin1 NOT NULL,
  `usu_operador` varchar(120) CHARACTER SET latin1 NOT NULL COMMENT 'usuario',
  `pass_operador` varchar(120) CHARACTER SET latin1 NOT NULL COMMENT 'contraseÃ±a',
  `rol_operador` int(11) NOT NULL COMMENT 'nivel de acceso',
  `nrol_operador` varchar(120) CHARACTER SET latin1 NOT NULL,
  `img_operador` longtext CHARACTER SET latin1 NOT NULL COMMENT 'imagen',
  PRIMARY KEY (`idx_operador`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `tbl_operador` VALUES (1,0000000000,"ADMIN","ADMIN",0000000000,000000000,"admin@svm.com","admin","21232f297a57a5a743894a0e4a801fc3",7,"Administrador","cedula.jpg"),
(4,2222222222,"USUARIO","USUARIOAP",9889879797,"IYI87","usuario@svm.com","us-2222222222","69393a8bbc80dec9f380bc7014ce71cc",1,"Vendedor","foto.jpg"),
(5,9999999999,"JUAN","LOPEX",9999999990,"PINPAN RIGHT","e@mail.com","us-9999999999","254c5a76d669478d2b93ce9ec10d5f11",1,"Vendedor","foto.jpg");


DROP TABLE IF EXISTS `tbl_parametros`;

CREATE TABLE `tbl_parametros` (
  `idx` int(11) NOT NULL AUTO_INCREMENT,
  `tittle_parametros` varchar(120) CHARACTER SET latin1 NOT NULL,
  `iva_parametros` decimal(7,2) DEFAULT NULL,
  `nro_cotizacion` int(11) NOT NULL DEFAULT '0',
  `cont_f_cotiza` int(11) NOT NULL DEFAULT '0',
  `n_muestra` int(11) NOT NULL,
  `cont_muestra` int(11) NOT NULL,
  `con_cliente` int(11) NOT NULL DEFAULT '0',
  `n_informe` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idx`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `tbl_parametros` VALUES (1,"S.V.MEDICAL","0.12",92,40,173,16,98,26);


DROP TABLE IF EXISTS `tbl_perdido`;

CREATE TABLE `tbl_perdido` (
  `idx_perdido` varchar(11) NOT NULL,
  `fech_perdido` date NOT NULL,
  `hora_perdido` time NOT NULL,
  `idx_clientes` int(11) NOT NULL,
  `idx_operador` int(10) NOT NULL,
  `totaliva_perdido` decimal(7,2) NOT NULL,
  `totalsiniva_perdido` decimal(7,2) NOT NULL,
  `totalbono` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_perdido` decimal(7,2) NOT NULL,
  PRIMARY KEY (`idx_perdido`),
  KEY `operador` (`idx_operador`),
  KEY `cliente` (`idx_clientes`),
  CONSTRAINT `cliente` FOREIGN KEY (`idx_clientes`) REFERENCES `tbl_clientes` (`idx_clientes`),
  CONSTRAINT `operador` FOREIGN KEY (`idx_operador`) REFERENCES `tbl_operador` (`idx_operador`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_perdido` VALUES ("COT00039","2019-05-27","00:28:00",5,4,"0.00","0.00","0.00","721.92"),
("COT00040","2019-05-27","00:41:00",6,5,"0.00","0.00","16.38","81.90");


DROP TABLE IF EXISTS `tbl_rutas`;

CREATE TABLE `tbl_rutas` (
  `idx_rutas` int(11) NOT NULL AUTO_INCREMENT,
  `idx_ciudades` int(11) NOT NULL,
  `nom_rutas` varchar(120) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `idx_operador` int(11) NOT NULL,
  PRIMARY KEY (`idx_rutas`),
  KEY `ciudades` (`idx_ciudades`),
  CONSTRAINT `ciudades` FOREIGN KEY (`idx_ciudades`) REFERENCES `tbl_ciudades` (`idx_ciudades`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `tbl_rutas` VALUES (21,3,"BOMBOLI",4),
(22,3,"CALIFORNIA",5),
(23,3,"JEJEJE",1);


DROP TABLE IF EXISTS `tbl_sql`;

CREATE TABLE `tbl_sql` (
  `idx_sql` int(11) NOT NULL AUTO_INCREMENT,
  `sql_sql` longtext NOT NULL,
  `tipo_sql` varchar(120) NOT NULL,
  `tabla_sql` varchar(120) NOT NULL,
  `accion_sql` varchar(120) NOT NULL,
  PRIMARY KEY (`idx_sql`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_sql` VALUES (1,"delimiter $$\ncreate procedure p_i_operador(ced_operador varchar(10),nom_operador varchar(120),ape_operador varchar(120),tel_operador varchar(10),dir_operador varchar(120),email_operador varchar(120),usu_operador varchar(120),pass_operador varchar(120),rol_operador int,nrol_operador varchar(120),img_operador longtext)\nbegin\ndeclare pass_operador2 varchar(120);\nif not exists(select * from tbl_operador where tbl_operador.ced_operador=ced_operador  )then\nset pass_operador2=md5(pass_operador);\ninsert into tbl_operador value(ced_operador  ,nom_operador  ,ape_operador  ,tel_operador ,dir_operador ,email_operador ,usu_operador ,pass_operador2,rol_operador,nrol_operador,img_operador);\nend if;\nend;\n\n$$ delimiter ;","procedimiento almecenado","operador","insertar"),
(2,"delimiter $$\ncreate procedure p_e_operador(id int)\n\tbegin\n\t\tif not exists(select * FROM tbl_perdido where tbl_perdido.idx_operador=id)then\n\t\t\tdelete from tbl_operador WHERE tbl_operador.idx_operador=id;\n\t\tend if;\n\tend;\n$$ delimiter ;","procedimiento almacenado","operador","eliminar"),
(3,"\nDELIMITER $$\nUSE `bdd_ruta`$$\nCREATE PROCEDURE `p_i_ciudades` (nom_ciudades varchar(120))\nBEGIN\nif not exists(select * from tbl_ciudades where tbl_ciudades.nom_ciudades=nom_ciudades  )then\ninsert into tbl_ciudades values(null,nom_ciudades);\nend if;\n\nEND$$\n\nDELIMITER ;\n\n","pa","ciudades","insertar"),
(4,"CREATE PROCEDURE `p_i_clientes`(cru_clientes varchar(10),nom_clientes varchar(120),\nape_clientes varchar(120),idx_ruta int,dir_clientes varchar(120),telf_clientes varchar(10),cel_clientes varchar(10),email_clientes varchar(120),emp_clientes varchar(120))\nBEGIN\nif not exists(Select * from tbl_clientes where tbl_clientes.cru_clientes=cru_clientes)then \ninsert into tbl_clientes value(null,cru_clientes,nom_clientes,ape_clientes,idx_ruta,dir_clientes,telf_clientes,cel_clientes,email_clientes,emp_clientes);\nend if;\nEND","pa","clientes","insertar"),
(5,"CREATE PROCEDURE `p_e_ciudades`(id int)\nBEGIN\nif not exists(Select * from tbl_rutas tr where tr.idx_ciudades=id)then\ndelete from tbl_ciudades  where tbl_ciudades.idx_ciudades=id;\nend if;\nEND","pa","ciudades","eliminar"),
(6," \nCREATE  PROCEDURE `p_i_ruta`(nom_ruta varchar(120),idx_ciudades int)\nBEGIN \ndeclare contar int;\n if not exists(select * from tbl_rutas where tbl_rutas.nom_rutas=nom_ruta and tbl_rutas.idx_ciudades=idx_ciudades )then\n insert into tbl_rutas value(null,idx_ciudades,nom_ruta);\n select count(*) into contar from tbl_rutas where tbl_rutas.idx_ciudades=idx_ciudades;\n update tbl_ciudades set cont_ciudades=contar where tbl_ciudades.idx_ciudades=idx_ciudades;\n end if;\n END;\n ","pa","ruta","insertar"),
(7," CREATE PROCEDURE `p_i_tipo`(desc_tipo varchar(120))\n BEGIN\n if not exists(select *  from tbl_tipo where tbl_tipo.desc_tipo=desc_tipo) then\n insert into tbl_tipo value(null,desc_tipo,0);\n end if;\n END;\n ","pa","tipo","insertar"),
(8," \nCREATE PROCEDURE `p_e_tipo`(id int)\nBEGIN\nif not exists(select * from tbl_inventario where idx_tipo=id )then\ndelete from tbl_tipo where idx_tipo =id;\nend if;\nEND;\n ","pa","tipo ","eliminar"),
(9," \n  CREATE PROCEDURE `p_e_rutas`(id  int)\nBEGIN\ndeclare contar int;\ndeclare idx_ciudades int;\nselect tbl_rutas.idx_ciudades into idx_ciudades from tbl_rutas where tbl_rutas.idx_rutas=id;\nif not  exists(SELECT * from tbl_clientes tbl_p,tbl_rutas tbl_o  where tbl_p.idx_rutas=tbl_o.idx_rutas     and tbl_o.idx_rutas=id)then\ndelete from tbl_rutas where idx_rutas=id;\n\nselect count(*) into contar from tbl_rutas where tbl_rutas.idx_ciudades=idx_ciudades;\n update tbl_ciudades set cont_ciudades=contar where tbl_ciudades.idx_ciudades=idx_ciudades;\nend  if;\nEND;\n ","pa","ruta","eliminar"),
(10,"create procedure p_e_clientes(id int)\n\tbegin\n\t\tif not exists(SELECT * from   tbl_perdido,tbl_clientes tbl_o  where tbl_perdido.idx_clientes=tbl_o.idx_clientes \n    and tbl_o.idx_clientes=id)then\n\t\t\tdelete from tbl_clientes WHERE tbl_clientes.idx_clientes=id;\n\t\tend if;\n\tend;","pa","cliente","eliminar"),
(11,"CREATE  PROCEDURE `p_i_invetario`(nomp_producto varchar(120),idx_tipo int,prec_producto decimal(7.2),img_producto longtext,iva_producto int,promo_producto int,caract_inventario longtext)\nBEGIN \ndeclare contar int;\n if not exists(select * from tbl_inventario where tbl_inventario.nomp_producto=nomp_producto and tbl_inventario.idx_tipo=idx_tipo)then\n insert into tbl_inventario value(null,nomp_producto,idx_tipo,prec_producto,img_producto,iva_producto,promo_producto,caract_inventario);\n select count(*) into contar from tbl_rutas where tbl_inventario.idx_tipo=idx_tipo;\n update idx_tipo set contar_tipo=contar where idx_tipo.idx_tipo=idx_tipo;\n end if;\n END;","pa","invetario ","insertar"),
(12,"   CREATE PROCEDURE `p_e_inventario`(id  int)\n BEGIN\n declare contar int;\n declare idx_tipo int;\n select tbl_inventario.idx_tipo into idx_tipo from tbl_inventario where tbl_inventario.idx_producto=id;\n if not  exists(SELECT * from tbl_det_pedido ,tbl_inventario   where tbl_det_pedido.idx_producto=tbl_inventario.idx_producto \n    and tbl_inventario.idx_producto=id)then\n delete from tbl_inventario where idx_producto=id;\n \n select count(*) into contar from tbl_rutas where tbl_rutas.idx_ciudades=idx_ciudades;\n  update tbl_ciudades set cont_ciudades=contar where tbl_ciudades.idx_tipo=idx_tipo;\n end  if;\n END;","pa","inventario","eliminar");


DROP TABLE IF EXISTS `tbl_tipo`;

CREATE TABLE `tbl_tipo` (
  `idx_tipo` int(11) NOT NULL AUTO_INCREMENT,
  `desc_tipo` varchar(120) NOT NULL,
  `contar_tipo` int(11) DEFAULT NULL,
  PRIMARY KEY (`idx_tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_tipo` VALUES (1,"VALSARTAN",1),
(2,"ITRACONAZOL",1),
(3,"CENTELLA ASIATICA",1),
(6,"CIPROFLOXACINA ",1),
(7,"CLINDAMICINA",2),
(8,"POLICRESULENO",1),
(9,"PARACETAMOL",1),
(10,"IBUPROFENO",6),
(11,"BETAMETASONA, CLOTRIMAZOL, GENTAMICINA",1),
(12,"AMOXICILINA",4),
(13,"NITROFURANTOINA",1),
(14,"NIMESULIDA",1),
(15,"MELOXICAM",3),
(16,"NITAZOXANIDA",4),
(17,"SULTAMICILINA",1),
(21,"CEFUROXIMA",2),
(22,"A1",0),
(23,"A2",0),
(24,"A3",0),
(25,"A4",0),
(26,"A5",0),
(27,"A6",0),
(28,"A7",0),
(29,"A8",0),
(30,"A9",0),
(34,"A10",0),
(35,"A32",0);


DROP TABLE IF EXISTS `tbl_visitas`;

CREATE TABLE `tbl_visitas` (
  `idx_visita` int(11) NOT NULL AUTO_INCREMENT,
  `fech_visita` date NOT NULL,
  `cedu_visita` varchar(10) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `nom_visita` varchar(120) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `dir_visita` varchar(120) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `idx_especialidades` int(11) NOT NULL,
  `idx_rutas` int(11) NOT NULL,
  `idx_operador` int(11) NOT NULL,
  `hora_visitas` time NOT NULL,
  PRIMARY KEY (`idx_visita`),
  KEY `especialidades` (`idx_especialidades`),
  KEY `fk2` (`idx_operador`),
  KEY `fk1` (`idx_rutas`),
  CONSTRAINT `especialidades` FOREIGN KEY (`idx_especialidades`) REFERENCES `tbl_especialidades` (`idx_especialidades`),
  CONSTRAINT `fk1` FOREIGN KEY (`idx_rutas`) REFERENCES `tbl_rutas` (`idx_rutas`),
  CONSTRAINT `fk2` FOREIGN KEY (`idx_operador`) REFERENCES `tbl_operador` (`idx_operador`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `tbl_visitas` VALUES (54,"2019-06-02","CLI00097","BRYAN CORNEJO","TSACHILA Y  GUAYAQUIL",1,23,1,"19:17:00");


DROP TABLE IF EXISTS `tbl_visitas_detalle`;

CREATE TABLE `tbl_visitas_detalle` (
  `idx_visitas_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `idx_visitas` int(11) NOT NULL,
  `n_muestra` varchar(11) COLLATE utf8_spanish2_ci NOT NULL,
  `total_cant` int(11) NOT NULL,
  PRIMARY KEY (`idx_visitas_detalle`),
  KEY `visita` (`idx_visitas`),
  CONSTRAINT `visita` FOREIGN KEY (`idx_visitas`) REFERENCES `tbl_visitas` (`idx_visita`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

INSERT INTO `tbl_visitas_detalle` VALUES (9,54,"PAR00173",42);


DROP TABLE IF EXISTS `tmp_coti_detalle`;

CREATE TABLE `tmp_coti_detalle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcoti` int(11) NOT NULL,
  `idproducto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `promocion` int(11) NOT NULL DEFAULT '0',
  `precio` decimal(9,2) NOT NULL,
  `iva` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `tmp_coti_detalle` VALUES (1,64,1,10,1,"16.38","0.00"),
(2,65,1,10,1,"16.38","0.00"),
(3,66,1,2,1,"16.38","0.00"),
(4,67,1,2,1,"16.38","0.00"),
(5,68,3,2,0,"15.00","0.00"),
(6,69,3,2,0,"15.00","0.00"),
(7,69,1,3,1,"16.38","0.00"),
(8,69,2,2,0,"27.58","0.00"),
(9,70,1,5,1,"16.38","0.00"),
(10,72,2,1,1,"27.58","0.00"),
(11,73,2,1,1,"27.58","0.00"),
(12,74,4,2,0,"7.92","0.00"),
(16,76,2,3,0,"27.58","0.00"),
(22,78,3,2,0,"15.00","0.00"),
(28,80,2,1,0,"27.58","0.00"),
(34,82,2,1,0,"27.58","0.00"),
(40,84,2,156,0,"27.58","0.00"),
(46,86,2,1,0,"27.58","0.00"),
(47,88,30,32,0,"22.56","0.00"),
(48,89,30,32,0,"22.56","0.00"),
(50,91,1,5,1,"16.38","0.00");


DROP TABLE IF EXISTS `tmp_det_muestra`;

CREATE TABLE `tmp_det_muestra` (
  `id_tmp_det` int(11) NOT NULL AUTO_INCREMENT,
  `n_muestra` int(11) NOT NULL,
  `idx_muestra` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha` date NOT NULL,
  PRIMARY KEY (`id_tmp_det`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;



DROP TABLE IF EXISTS `v_detalle`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_detalle` AS select `tmp_coti_detalle`.`id` AS `id`,`tmp_coti_detalle`.`idcoti` AS `idcoti`,`tmp_coti_detalle`.`idproducto` AS `idproducto`,`tbl_inventario`.`nomp_producto` AS `nomp_producto`,`tmp_coti_detalle`.`cantidad` AS `cantidad`,`tmp_coti_detalle`.`promocion` AS `promocion`,`tmp_coti_detalle`.`precio` AS `precio`,`tmp_coti_detalle`.`iva` AS `iva` from (`tmp_coti_detalle` join `tbl_inventario` on((`tbl_inventario`.`idx_producto` = `tmp_coti_detalle`.`idproducto`)));

INSERT INTO `v_detalle` VALUES (1,64,1,"ATENNOR",10,1,"16.38","0.00"),
(2,65,1,"ATENNOR",10,1,"16.38","0.00"),
(3,66,1,"ATENNOR",2,1,"16.38","0.00"),
(4,67,1,"ATENNOR",2,1,"16.38","0.00"),
(5,68,3,"CENTELAR GEL",2,0,"15.00","0.00"),
(6,69,3,"CENTELAR GEL",2,0,"15.00","0.00"),
(7,69,1,"ATENNOR",3,1,"16.38","0.00"),
(8,69,2,"ANTIFUX",2,0,"27.58","0.00"),
(9,70,1,"ATENNOR",5,1,"16.38","0.00"),
(10,72,2,"ANTIFUX",1,1,"27.58","0.00"),
(11,73,2,"ANTIFUX",1,1,"27.58","0.00"),
(12,74,4,"CIFLOBAC TABL 500 MG",2,0,"7.92","0.00"),
(16,76,2,"ANTIFUX",3,0,"27.58","0.00"),
(22,78,3,"CENTELAR GEL",2,0,"15.00","0.00"),
(28,80,2,"ANTIFUX",1,0,"27.58","0.00"),
(34,82,2,"ANTIFUX",1,0,"27.58","0.00"),
(40,84,2,"ANTIFUX",156,0,"27.58","0.00"),
(46,86,2,"ANTIFUX",1,0,"27.58","0.00"),
(47,88,30,"XIMAX TABLETAS 500",32,0,"22.56","0.00"),
(48,89,30,"XIMAX TABLETAS 500",32,0,"22.56","0.00"),
(50,91,1,"ATENNOR",5,1,"16.38","0.00");


DROP TABLE IF EXISTS `v_detalle_muestra`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_detalle_muestra` AS select `tmp_det_muestra`.`id_tmp_det` AS `id_tmp_det`,`tmp_det_muestra`.`n_muestra` AS `n_muestra`,`tmp_det_muestra`.`fecha` AS `fecha`,`view_muestra`.`nomp_producto` AS `nomp_producto`,`tmp_det_muestra`.`cantidad` AS `cantidad` from (`view_muestra` join `tmp_det_muestra`) where (`view_muestra`.`idx_muestra` = `tmp_det_muestra`.`idx_muestra`);



DROP TABLE IF EXISTS `v_medico`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_medico` AS select `tbl_medico`.`ced_medico` AS `ced_medico`,ucase(`tbl_medico`.`nom_medi`) AS `Medico`,ucase(`tbl_medico`.`dir_medico`) AS `Direccion`,ucase(concat(`tbl_ciudades`.`nom_ciudades`,' / ',`tbl_rutas`.`nom_rutas`)) AS `Localizacion`,`tbl_especialidades`.`esp_especialidades` AS `esp_especialidades`,`tbl_medico`.`ruta` AS `ruta`,`tbl_rutas`.`idx_ciudades` AS `idx_ciudades`,`tbl_medico`.`especialidad` AS `especialidad`,`tbl_medico`.`idxm` AS `idxm`,`tbl_medico`.`idx_operador` AS `idx_operador` from (((`tbl_medico` join `tbl_rutas` on((`tbl_rutas`.`idx_rutas` = `tbl_medico`.`ruta`))) join `tbl_especialidades` on((`tbl_especialidades`.`idx_especialidades` = `tbl_medico`.`especialidad`))) join `tbl_ciudades` on((`tbl_rutas`.`idx_ciudades` = `tbl_ciudades`.`idx_ciudades`)));

INSERT INTO `v_medico` VALUES ("CLI00097","BRYAN CORNEJO","TSACHILA Y  GUAYAQUIL","SANTO DOMINGO / JEJEJE","GINECOLOGIA",23,3,1,1,1);


DROP TABLE IF EXISTS `v_pedido`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_pedido` AS select `tbl_perdido`.`idx_perdido` AS `idx_perdido`,`tbl_perdido`.`fech_perdido` AS `fech_perdido`,`tbl_clientes`.`emp_clientes` AS `emp_clientes`,`tbl_clientes`.`cru_clientes` AS `cru_clientes`,concat(`tbl_clientes`.`nom_clientes`,' ',`tbl_clientes`.`ape_clientes`) AS `Cliente`,`tbl_clientes`.`dir_clientes` AS `dir_clientes`,`tbl_clientes`.`telf_clientes` AS `telf_clientes`,`tbl_clientes`.`email_clientes` AS `email_clientes`,`tbl_clientes`.`idx_rutas` AS `idx_rutas`,`tbl_rutas`.`idx_ciudades` AS `idx_ciudades`,concat(`tbl_operador`.`nom_operador`,' ',`tbl_operador`.`ape_operador`) AS `Operador`,`tbl_perdido`.`hora_perdido` AS `hora_perdido`,`tbl_perdido`.`totalbono` AS `totalbono`,`tbl_perdido`.`totaliva_perdido` AS `totaliva_perdido`,`tbl_perdido`.`totalsiniva_perdido` AS `totalsiniva_perdido`,`tbl_perdido`.`total_perdido` AS `total_perdido`,`tbl_rutas`.`nom_rutas` AS `nom_rutas`,`tbl_ciudades`.`nom_ciudades` AS `nom_ciudades`,`tbl_clientes`.`idx_clientes` AS `idx_clientes`,`tbl_perdido`.`idx_operador` AS `idx_operador` from ((((`tbl_perdido` join `tbl_clientes` on((`tbl_perdido`.`idx_clientes` = `tbl_clientes`.`idx_clientes`))) join `tbl_operador` on((`tbl_perdido`.`idx_operador` = `tbl_operador`.`idx_operador`))) join `tbl_rutas` on((`tbl_clientes`.`idx_rutas` = `tbl_rutas`.`idx_rutas`))) join `tbl_ciudades` on((`tbl_rutas`.`idx_ciudades` = `tbl_ciudades`.`idx_ciudades`)));

INSERT INTO `v_pedido` VALUES ("COT00039","2019-05-27","PC-SANTO DOMINGO",1717565665,"BRYAN CORNEJO","TSACHILA Y  GUAYAQUIL",0959113935,"riqbran@hotmail.com",21,3,"USUARIO USUARIOAP","00:28:00","0.00","0.00","0.00","721.92","BOMBOLI","SANTO DOMINGO",5,4),
("COT00040","2019-05-27","D",1720836400,"LOLI K","EW",32,"d@m.cpm",22,3,"JUAN LOPEX","00:41:00","16.38","0.00","0.00","81.90","CALIFORNIA","SANTO DOMINGO",6,5);


DROP TABLE IF EXISTS `view_clientes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_clientes` AS select `tbl_clientes`.`idx_clientes` AS `idx_clientes`,`tbl_clientes`.`cru_clientes` AS `cru_clientes`,concat(`tbl_clientes`.`nom_clientes`,' ',`tbl_clientes`.`ape_clientes`) AS `concat(tbl_clientes.nom_clientes,' ',tbl_clientes.ape_clientes)`,`tbl_ciudades`.`nom_ciudades` AS `nom_ciudades`,`tbl_rutas`.`nom_rutas` AS `nom_rutas`,`tbl_clientes`.`dir_clientes` AS `dir_clientes`,`tbl_clientes`.`emp_clientes` AS `emp_clientes` from ((`tbl_clientes` join `tbl_ciudades`) join `tbl_rutas`) where ((`tbl_clientes`.`idx_rutas` = `tbl_rutas`.`idx_rutas`) and (`tbl_rutas`.`idx_ciudades` = `tbl_ciudades`.`idx_ciudades`));

INSERT INTO `view_clientes` VALUES (5,1717565665,"BRYAN CORNEJO","SANTO DOMINGO","BOMBOLI","TSACHILA Y  GUAYAQUIL","PC-SANTO DOMINGO"),
(6,1720836400,"LOLI K","SANTO DOMINGO","CALIFORNIA","EW","D");


DROP TABLE IF EXISTS `view_inventario`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_inventario` AS select `tbl_inventario`.`idx_producto` AS `idx_producto`,`tbl_inventario`.`nomp_producto` AS `nomp_producto`,`tbl_inventario`.`prec_producto` AS `prec_producto`,`tbl_inventario`.`promo_producto` AS `promo_producto`,`tbl_tipo`.`desc_tipo` AS `desc_tipo`,`tbl_inventario`.`caract_inventario` AS `caract_inventario` from (`tbl_tipo` join `tbl_inventario`) where (`tbl_inventario`.`idx_tipo` = `tbl_tipo`.`idx_tipo`);

INSERT INTO `view_inventario` VALUES (1,"ATENNOR","16.38",1,"VALSARTAN","Caja x 14 Tabletas"),
(2,"ANTIFUX","27.58",0,"ITRACONAZOL","Caja x 14 C&aacute;psulas"),
(3,"CENTELAR GEL","15.00",0,"CENTELLA ASIATICA","Tubo 50 g"),
(4,"CIFLOBAC TABL 500 MG","7.92",0,"CIPROFLOXACINA ","Tabletas Caja x 10"),
(5,"COLPOSTAT OVULOS","21.00",0,"CLINDAMICINA","Ovulos Caja x 7"),
(6,"COLPOSTAT CREMA","16.50",0,"CLINDAMICINA","Crema 30 g Caja x 1"),
(7,"CRESULIV OVULOS","15.78",0,"POLICRESULENO","Ovulos Caja x 6 "),
(8,"DILUPHEN SOBRES","10.08",0,"PARACETAMOL","Sobres Caja x 20 "),
(9,"DISFEBRAL SIMPLE","2.70",0,"IBUPROFENO","Suspensi&oacute;n 120 ml "),
(10,"DISFEBRAL FAST 400","6.40",0,"IBUPROFENO","Caja x 16 C&aacute;psulas Blandas"),
(11,"DISFEBRAL FORTE","4.11",0,"IBUPROFENO","Suspensi&oacute;n 120 ml"),
(12,"DISFEBRAL GOTAS","1.94",0,"IBUPROFENO","Gotas Suspensi&oacute;n 30 ml"),
(13,"DISFEBRAL 400","4.20",0,"IBUPROFENO","Comprimidos Caja x 20 "),
(14,"DISFEBRAL 600","6.00",0,"IBUPROFENO","Tabletas Caja x 20"),
(15,"ELODERM CREMA","5.75",0,"BETAMETASONA, CLOTRIMAZOL, GENTAMICINA","Tubo 30 g"),
(16,"EPEROX IBL TABLETAS","26.00",0,"AMOXICILINA","Tabletas Dispersables Caja x 14"),
(17,"EPEROX IBL SUSPENSION","11.50",0,"AMOXICILINA","Suspension 100 ml"),
(18,"IVUMOD CAPSULAS","5.83",0,"NITROFURANTOINA","C&aacute;psulas Caja x 20"),
(19,"LIDEMIN SOBRES","18.00",0,"NIMESULIDA","Sobres Caja x 30 "),
(20,"MIOLOX 75MG ","3.55",0,"MELOXICAM","Tabletas Caja x 10"),
(21,"MIOLOX 15","6.08",0,"MELOXICAM","Tabletas Caja x 10"),
(22,"MIOLOX GRANULADO","24.92",0,"MELOXICAM","Sobres Caja x 30"),
(23,"NITELMIN 200 ","5.30",0,"NITAZOXANIDA","Tabletas Dispersable Caja x 6"),
(24,"NITELMIN 500","8.40",0,"NITAZOXANIDA","tableta caja x6"),
(25,"NITELMIN SUSPENSION 60","6.57",0,"NITAZOXANIDA","Suspensi&oacute;n 30 ml"),
(26,"NITELMIN SUSPENSION 30","3.29",0,"NITAZOXANIDA","Suspension 30 ml"),
(27,"SULTAPRIN","13.40",0,"SULTAMICILINA","Tabletas Dispersables Caja x 10"),
(28,"UOSOMOX 250 mg 5ml PPS","3.73",0,"AMOXICILINA","Polvo para suspension 100 ml"),
(29,"UOSOMOX CAPSULAS ","4.60",0,"AMOXICILINA","Capsulas Caja x 20"),
(30,"XIMAX TABLETAS 500","22.56",0,"CEFUROXIMA","Tabletas dispersables caja x 10 "),
(31,"XIMAX SUSPENSION 250","18.00",0,"CEFUROXIMA","Suspensi&oacute;n 70 mL 250 mg5 mL");


DROP TABLE IF EXISTS `view_muestra`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_muestra` AS select `tbl_muestra`.`idx_muestra` AS `idx_muestra`,`tbl_inventario`.`nomp_producto` AS `nomp_producto`,`tbl_muestra`.`fecha_muestra` AS `fecha_muestra`,`tbl_muestra`.`cont_muestra` AS `cont_muestra`,`tbl_muestra`.`idx_operador` AS `idx_operador` from (`tbl_muestra` join `tbl_inventario`) where (`tbl_muestra`.`idx_producto` = `tbl_inventario`.`idx_producto`);

INSERT INTO `view_muestra` VALUES (3,"ATENNOR","2019-06-01",16,4),
(5,"ANTIFUX","2019-05-08",16,4),
(6,"ATENNOR","2019-05-08",16,4),
(7,"COLPOSTAT CREMA","2019-05-08",16,4);


DROP TABLE IF EXISTS `view_operador`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_operador` AS select `tbl_operador`.`idx_operador` AS `idx_operador`,`tbl_operador`.`ced_operador` AS `ced_operador`,concat(`tbl_operador`.`nom_operador`,' ',`tbl_operador`.`ape_operador`) AS `operador`,`tbl_operador`.`tel_operador` AS `tel_operador`,`tbl_operador`.`dir_operador` AS `dir_operador`,`tbl_operador`.`email_operador` AS `email_operador`,`tbl_operador`.`nrol_operador` AS `nrol_operador` from `tbl_operador`;

INSERT INTO `view_operador` VALUES (1,0000000000,"ADMIN ADMIN",0000000000,000000000,"admin@svm.com","Administrador"),
(4,2222222222,"USUARIO USUARIOAP",9889879797,"IYI87","usuario@svm.com","Vendedor"),
(5,9999999999,"JUAN LOPEX",9999999990,"PINPAN RIGHT","e@mail.com","Vendedor");


DROP TABLE IF EXISTS `view_rutas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_rutas` AS select `tbl_rutas`.`idx_rutas` AS `idx_rutas`,`tbl_ciudades`.`nom_ciudades` AS `nom_ciudades`,`tbl_rutas`.`nom_rutas` AS `nom_rutas` from (`tbl_rutas` join `tbl_ciudades`) where (`tbl_ciudades`.`idx_ciudades` = `tbl_rutas`.`idx_ciudades`);

INSERT INTO `view_rutas` VALUES (21,"SANTO DOMINGO","BOMBOLI"),
(22,"SANTO DOMINGO","CALIFORNIA"),
(23,"SANTO DOMINGO","JEJEJE");


DROP TABLE IF EXISTS `view_tbl_citas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_tbl_citas` AS select `tbl_citas`.`id_citas` AS `id_citas`,date_format(`tbl_citas`.`fecha_citas`,'%d-%m-%Y') AS `fecha_citas`,date_format(`tbl_citas`.`hora_citas`,' %H:%i') AS `hora_citas`,concat(`tbl_clientes`.`nom_clientes`,' ',`tbl_clientes`.`ape_clientes`) AS `cliente`,`tbl_citas`.`estado_citas` AS `estado_citas`,`tbl_citas`.`obseravacion_citas` AS `obseravacion_citas`,concat(`tbl_operador`.`nom_operador`,' ',`tbl_operador`.`ape_operador`) AS `operador`,`tbl_citas`.`idx_clientes` AS `idx_clientes`,`tbl_citas`.`idx_operador` AS `idx_operador` from ((`tbl_citas` join `tbl_clientes`) join `tbl_operador`) where ((`tbl_citas`.`idx_clientes` = `tbl_clientes`.`idx_clientes`) and (`tbl_citas`.`idx_operador` = `tbl_operador`.`idx_operador`));

INSERT INTO `view_tbl_citas` VALUES (2,"26-05-2019"," 23:33","BRYAN CORNEJO","activo","","USUARIO USUARIOAP",5,4),
(3,"27-05-2019"," 15:06","LOLI K","activo","","JUAN LOPEX",6,5);


DROP TABLE IF EXISTS `view_tbl_det_muestra`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_tbl_det_muestra` AS select `tbl_det_muestra`.`idx_det_muestra` AS `n_muestra`,`view_muestra`.`nomp_producto` AS `nomp_producto`,`tbl_det_muestra`.`fecha_det_muestra` AS `fecha`,`tbl_det_muestra`.`cant_det_muestra` AS `cantidad`,`tbl_det_muestra`.`idx_muestra` AS `id_tmp_det`,`tbl_det_muestra`.`idx_vista` AS `idx_vista` from (`tbl_det_muestra` join `view_muestra`) where (`tbl_det_muestra`.`idx_muestra` = `view_muestra`.`idx_muestra`);

INSERT INTO `view_tbl_det_muestra` VALUES ("PAR00159","ATENNOR","2019-06-01",32,3,52),
("PAR00173","ATENNOR","2019-06-02",42,3,54);


DROP TABLE IF EXISTS `view_tbl_det_pedidos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_tbl_det_pedidos` AS select `tbl_det_pedido`.`idx_det_pedido` AS `idx_det_pedido`,`tbl_det_pedido`.`idx_perdido` AS `idx_perdido`,`tbl_det_pedido`.`idx_producto` AS `idx_producto`,`tbl_det_pedido`.`cant_det_pedido` AS `cantidad`,`tbl_det_pedido`.`pre_det_pedido` AS `precio`,`tbl_det_pedido`.`pro_det_pedido` AS `promocion`,`tbl_det_pedido`.`iva_det_pedido` AS `iva`,`tbl_det_pedido`.`subt_det_pedido` AS `subt_det_pedido`,`tbl_inventario`.`nomp_producto` AS `nomp_producto` from (`tbl_det_pedido` join `tbl_inventario` on((`tbl_det_pedido`.`idx_producto` = `tbl_inventario`.`idx_producto`)));

INSERT INTO `view_tbl_det_pedidos` VALUES (1,"COT00039",30,32,"22.56",0,"0.00","721.92","XIMAX TABLETAS 500"),
(2,"COT00040",1,5,"16.38",1,"0.00","98.28","ATENNOR");


DROP TABLE IF EXISTS `view_tbl_perdido_v1`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_tbl_perdido_v1` AS select concat(date_format(`tbl_perdido`.`fech_perdido`,'%d-%m-%Y'),'_','_','_','_',`tbl_perdido`.`hora_perdido`) AS `tiempo`,`tbl_perdido`.`idx_perdido` AS `idx_perdido`,`tbl_perdido`.`totaliva_perdido` AS `totaliva_perdido`,`tbl_perdido`.`totalsiniva_perdido` AS `totalsiniva_perdido`,`tbl_perdido`.`total_perdido` AS `total_perdido`,`tbl_perdido`.`idx_clientes` AS `idx_clientes`,concat(`tbl_clientes`.`nom_clientes`,' ',`tbl_clientes`.`ape_clientes`) AS `cliente`,`tbl_perdido`.`idx_operador` AS `idx_operador`,concat(`tbl_operador`.`nom_operador`,' ',`tbl_operador`.`ape_operador`) AS `operador` from ((`tbl_perdido` join `tbl_clientes`) join `tbl_operador`) where ((`tbl_perdido`.`idx_clientes` = `tbl_clientes`.`idx_clientes`) and (`tbl_perdido`.`idx_operador` = `tbl_operador`.`idx_operador`)) order by `tbl_perdido`.`idx_perdido` desc;

INSERT INTO `view_tbl_perdido_v1` VALUES ("27-05-2019____00:41:00","COT00040","0.00","0.00","81.90",6,"LOLI K",5,"JUAN LOPEX"),
("27-05-2019____00:28:00","COT00039","0.00","0.00","721.92",5,"BRYAN CORNEJO",4,"USUARIO USUARIOAP");


DROP TABLE IF EXISTS `view_visitas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_visitas` AS select `tbl_visitas`.`idx_visita` AS `idx_visita`,`tbl_visitas`.`fech_visita` AS `fech_visita`,month(`tbl_visitas`.`fech_visita`) AS `mes_visita`,`tbl_visitas`.`cedu_visita` AS `cedu_visita`,`tbl_visitas`.`nom_visita` AS `nom_visita`,`tbl_especialidades`.`esp_especialidades` AS `esp_especialidades`,concat(`tbl_ciudades`.`nom_ciudades`,' / ',`tbl_rutas`.`nom_rutas`) AS `localizacion`,concat(`tbl_operador`.`nom_operador`,' ',`tbl_operador`.`ape_operador`) AS `operador`,`tbl_visitas`.`idx_especialidades` AS `idx_especialidades`,`tbl_visitas`.`idx_rutas` AS `idx_rutas`,`tbl_rutas`.`nom_rutas` AS `nom_rutas`,`tbl_rutas`.`idx_ciudades` AS `idx_ciudades`,`tbl_ciudades`.`nom_ciudades` AS `nom_ciudades`,`tbl_visitas`.`dir_visita` AS `dir_visita`,`tbl_operador`.`ced_operador` AS `ced_operador`,`tbl_operador`.`nom_operador` AS `nom_operador`,`tbl_visitas`.`idx_operador` AS `idx_operador` from ((((`tbl_visitas` join `tbl_especialidades` on((`tbl_especialidades`.`idx_especialidades` = `tbl_visitas`.`idx_especialidades`))) join `tbl_ciudades`) join `tbl_rutas` on(((`tbl_rutas`.`idx_rutas` = `tbl_visitas`.`idx_rutas`) and (`tbl_ciudades`.`idx_ciudades` = `tbl_rutas`.`idx_ciudades`)))) join `tbl_operador` on((`tbl_operador`.`idx_operador` = `tbl_visitas`.`idx_operador`)));

INSERT INTO `view_visitas` VALUES (54,"2019-06-02",6,"CLI00097","BRYAN CORNEJO","GINECOLOGIA","SANTO DOMINGO / JEJEJE","ADMIN ADMIN",1,23,"JEJEJE",3,"SANTO DOMINGO","TSACHILA Y  GUAYAQUIL",0000000000,"ADMIN",1);


DROP TABLE IF EXISTS `view_visitas_detalle`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_visitas_detalle` AS select `tbl_visitas_detalle`.`n_muestra` AS `n_muestra`,`view_visitas`.`nom_visita` AS `nom_visita`,`view_visitas`.`dir_visita` AS `dir_visita`,`view_visitas`.`operador` AS `operador`,`tbl_visitas_detalle`.`total_cant` AS `total_cant`,`tbl_visitas_detalle`.`idx_visitas_detalle` AS `idx_visitas_detalle`,`tbl_visitas_detalle`.`idx_visitas` AS `idx_vista`,`view_visitas`.`esp_especialidades` AS `esp_especialidades`,`view_visitas`.`fech_visita` AS `fech_visita`,`view_visitas`.`localizacion` AS `localizacion` from (`tbl_visitas_detalle` join `view_visitas` on((`view_visitas`.`idx_visita` = `tbl_visitas_detalle`.`idx_visitas`))) where (`tbl_visitas_detalle`.`idx_visitas` = `view_visitas`.`idx_visita`);

INSERT INTO `view_visitas_detalle` VALUES ("PAR00173","BRYAN CORNEJO","TSACHILA Y  GUAYAQUIL","ADMIN ADMIN",42,9,54,"GINECOLOGIA","2019-06-02","SANTO DOMINGO / JEJEJE");


SET foreign_key_checks = 1;
